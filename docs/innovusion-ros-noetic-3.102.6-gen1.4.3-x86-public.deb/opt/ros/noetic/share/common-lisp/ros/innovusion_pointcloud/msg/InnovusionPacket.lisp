; Auto-generated. Do not edit!


(cl:in-package innovusion_pointcloud-msg)


;//! \htmlinclude InnovusionPacket.msg.html

(cl:defclass <InnovusionPacket> (roslisp-msg-protocol:ros-message)
  ((has_table
    :reader has_table
    :initarg :has_table
    :type cl:boolean
    :initform cl:nil)
   (data
    :reader data
    :initarg :data
    :type (cl:vector cl:fixnum)
   :initform (cl:make-array 0 :element-type 'cl:fixnum :initial-element 0))
   (table
    :reader table
    :initarg :table
    :type (cl:vector cl:fixnum)
   :initform (cl:make-array 0 :element-type 'cl:fixnum :initial-element 0)))
)

(cl:defclass InnovusionPacket (<InnovusionPacket>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <InnovusionPacket>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'InnovusionPacket)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name innovusion_pointcloud-msg:<InnovusionPacket> is deprecated: use innovusion_pointcloud-msg:InnovusionPacket instead.")))

(cl:ensure-generic-function 'has_table-val :lambda-list '(m))
(cl:defmethod has_table-val ((m <InnovusionPacket>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader innovusion_pointcloud-msg:has_table-val is deprecated.  Use innovusion_pointcloud-msg:has_table instead.")
  (has_table m))

(cl:ensure-generic-function 'data-val :lambda-list '(m))
(cl:defmethod data-val ((m <InnovusionPacket>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader innovusion_pointcloud-msg:data-val is deprecated.  Use innovusion_pointcloud-msg:data instead.")
  (data m))

(cl:ensure-generic-function 'table-val :lambda-list '(m))
(cl:defmethod table-val ((m <InnovusionPacket>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader innovusion_pointcloud-msg:table-val is deprecated.  Use innovusion_pointcloud-msg:table instead.")
  (table m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <InnovusionPacket>) ostream)
  "Serializes a message object of type '<InnovusionPacket>"
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'has_table) 1 0)) ostream)
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'data))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:write-byte (cl:ldb (cl:byte 8 0) ele) ostream))
   (cl:slot-value msg 'data))
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'table))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:write-byte (cl:ldb (cl:byte 8 0) ele) ostream))
   (cl:slot-value msg 'table))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <InnovusionPacket>) istream)
  "Deserializes a message object of type '<InnovusionPacket>"
    (cl:setf (cl:slot-value msg 'has_table) (cl:not (cl:zerop (cl:read-byte istream))))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'data) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'data)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:aref vals i)) (cl:read-byte istream)))))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'table) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'table)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:aref vals i)) (cl:read-byte istream)))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<InnovusionPacket>)))
  "Returns string type for a message object of type '<InnovusionPacket>"
  "innovusion_pointcloud/InnovusionPacket")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'InnovusionPacket)))
  "Returns string type for a message object of type 'InnovusionPacket"
  "innovusion_pointcloud/InnovusionPacket")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<InnovusionPacket>)))
  "Returns md5sum for a message object of type '<InnovusionPacket>"
  "7e2d146dca202c24ec9fb671e35f1cff")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'InnovusionPacket)))
  "Returns md5sum for a message object of type 'InnovusionPacket"
  "7e2d146dca202c24ec9fb671e35f1cff")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<InnovusionPacket>)))
  "Returns full string definition for message of type '<InnovusionPacket>"
  (cl:format cl:nil "bool                    has_table          # table tag~%uint8[]                 data               # packet contents~%uint8[]                 table              # lidar table~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'InnovusionPacket)))
  "Returns full string definition for message of type 'InnovusionPacket"
  (cl:format cl:nil "bool                    has_table          # table tag~%uint8[]                 data               # packet contents~%uint8[]                 table              # lidar table~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <InnovusionPacket>))
  (cl:+ 0
     1
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'data) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 1)))
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'table) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 1)))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <InnovusionPacket>))
  "Converts a ROS message object to a list"
  (cl:list 'InnovusionPacket
    (cl:cons ':has_table (has_table msg))
    (cl:cons ':data (data msg))
    (cl:cons ':table (table msg))
))
