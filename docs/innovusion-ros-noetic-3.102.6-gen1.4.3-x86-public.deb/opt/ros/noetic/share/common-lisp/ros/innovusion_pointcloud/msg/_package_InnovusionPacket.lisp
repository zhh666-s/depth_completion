(cl:in-package innovusion_pointcloud-msg)
(cl:export '(HAS_TABLE-VAL
          HAS_TABLE
          DATA-VAL
          DATA
          TABLE-VAL
          TABLE
))