(cl:in-package innovusion_pointcloud-msg)
(cl:export '(TIMESTAMP-VAL
          TIMESTAMP
          SIZE-VAL
          SIZE
          IS_LAST_SCAN-VAL
          IS_LAST_SCAN
          PACKETS-VAL
          PACKETS
))