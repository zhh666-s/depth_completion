
(cl:in-package :asdf)

(defsystem "innovusion_pointcloud-msg"
  :depends-on (:roslisp-msg-protocol :roslisp-utils )
  :components ((:file "_package")
    (:file "InnovusionPacket" :depends-on ("_package_InnovusionPacket"))
    (:file "_package_InnovusionPacket" :depends-on ("_package"))
    (:file "InnovusionScan" :depends-on ("_package_InnovusionScan"))
    (:file "_package_InnovusionScan" :depends-on ("_package"))
  ))