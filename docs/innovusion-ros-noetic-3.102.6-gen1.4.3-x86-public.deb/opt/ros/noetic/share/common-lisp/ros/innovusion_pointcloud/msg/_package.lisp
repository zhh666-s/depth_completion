(cl:defpackage innovusion_pointcloud-msg
  (:use )
  (:export
   "<INNOVUSIONPACKET>"
   "INNOVUSIONPACKET"
   "<INNOVUSIONSCAN>"
   "INNOVUSIONSCAN"
  ))

