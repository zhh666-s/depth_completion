; Auto-generated. Do not edit!


(cl:in-package innovusion_pointcloud-msg)


;//! \htmlinclude InnovusionScan.msg.html

(cl:defclass <InnovusionScan> (roslisp-msg-protocol:ros-message)
  ((timestamp
    :reader timestamp
    :initarg :timestamp
    :type cl:float
    :initform 0.0)
   (size
    :reader size
    :initarg :size
    :type cl:integer
    :initform 0)
   (is_last_scan
    :reader is_last_scan
    :initarg :is_last_scan
    :type cl:boolean
    :initform cl:nil)
   (packets
    :reader packets
    :initarg :packets
    :type (cl:vector innovusion_pointcloud-msg:InnovusionPacket)
   :initform (cl:make-array 0 :element-type 'innovusion_pointcloud-msg:InnovusionPacket :initial-element (cl:make-instance 'innovusion_pointcloud-msg:InnovusionPacket))))
)

(cl:defclass InnovusionScan (<InnovusionScan>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <InnovusionScan>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'InnovusionScan)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name innovusion_pointcloud-msg:<InnovusionScan> is deprecated: use innovusion_pointcloud-msg:InnovusionScan instead.")))

(cl:ensure-generic-function 'timestamp-val :lambda-list '(m))
(cl:defmethod timestamp-val ((m <InnovusionScan>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader innovusion_pointcloud-msg:timestamp-val is deprecated.  Use innovusion_pointcloud-msg:timestamp instead.")
  (timestamp m))

(cl:ensure-generic-function 'size-val :lambda-list '(m))
(cl:defmethod size-val ((m <InnovusionScan>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader innovusion_pointcloud-msg:size-val is deprecated.  Use innovusion_pointcloud-msg:size instead.")
  (size m))

(cl:ensure-generic-function 'is_last_scan-val :lambda-list '(m))
(cl:defmethod is_last_scan-val ((m <InnovusionScan>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader innovusion_pointcloud-msg:is_last_scan-val is deprecated.  Use innovusion_pointcloud-msg:is_last_scan instead.")
  (is_last_scan m))

(cl:ensure-generic-function 'packets-val :lambda-list '(m))
(cl:defmethod packets-val ((m <InnovusionScan>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader innovusion_pointcloud-msg:packets-val is deprecated.  Use innovusion_pointcloud-msg:packets instead.")
  (packets m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <InnovusionScan>) ostream)
  "Serializes a message object of type '<InnovusionScan>"
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'timestamp))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'size)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'size)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'size)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'size)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'is_last_scan) 1 0)) ostream)
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'packets))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'packets))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <InnovusionScan>) istream)
  "Deserializes a message object of type '<InnovusionScan>"
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'timestamp) (roslisp-utils:decode-double-float-bits bits)))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'size)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'size)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'size)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'size)) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'is_last_scan) (cl:not (cl:zerop (cl:read-byte istream))))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'packets) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'packets)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'innovusion_pointcloud-msg:InnovusionPacket))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<InnovusionScan>)))
  "Returns string type for a message object of type '<InnovusionScan>"
  "innovusion_pointcloud/InnovusionScan")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'InnovusionScan)))
  "Returns string type for a message object of type 'InnovusionScan"
  "innovusion_pointcloud/InnovusionScan")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<InnovusionScan>)))
  "Returns md5sum for a message object of type '<InnovusionScan>"
  "0464247e42ae04f3fd847e0b2a973ba0")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'InnovusionScan)))
  "Returns md5sum for a message object of type 'InnovusionScan"
  "0464247e42ae04f3fd847e0b2a973ba0")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<InnovusionScan>)))
  "Returns full string definition for message of type '<InnovusionScan>"
  (cl:format cl:nil "float64                 timestamp~%uint32                  size~%bool                    is_last_scan~%InnovusionPacket[]      packets               # packet contents~%~%================================================================================~%MSG: innovusion_pointcloud/InnovusionPacket~%bool                    has_table          # table tag~%uint8[]                 data               # packet contents~%uint8[]                 table              # lidar table~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'InnovusionScan)))
  "Returns full string definition for message of type 'InnovusionScan"
  (cl:format cl:nil "float64                 timestamp~%uint32                  size~%bool                    is_last_scan~%InnovusionPacket[]      packets               # packet contents~%~%================================================================================~%MSG: innovusion_pointcloud/InnovusionPacket~%bool                    has_table          # table tag~%uint8[]                 data               # packet contents~%uint8[]                 table              # lidar table~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <InnovusionScan>))
  (cl:+ 0
     8
     4
     1
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'packets) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <InnovusionScan>))
  "Converts a ROS message object to a list"
  (cl:list 'InnovusionScan
    (cl:cons ':timestamp (timestamp msg))
    (cl:cons ':size (size msg))
    (cl:cons ':is_last_scan (is_last_scan msg))
    (cl:cons ':packets (packets msg))
))
