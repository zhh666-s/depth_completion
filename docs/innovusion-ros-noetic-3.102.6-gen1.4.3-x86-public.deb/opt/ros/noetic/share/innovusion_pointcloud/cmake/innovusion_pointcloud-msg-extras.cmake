set(innovusion_pointcloud_MESSAGE_FILES "msg/InnovusionPacket.msg;msg/InnovusionScan.msg")
set(innovusion_pointcloud_SERVICE_FILES "")
