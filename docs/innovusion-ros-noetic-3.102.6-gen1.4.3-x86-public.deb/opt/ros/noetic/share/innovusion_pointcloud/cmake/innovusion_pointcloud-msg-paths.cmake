# generated from genmsg/cmake/pkg-msg-paths.cmake.installspace.in

_prepend_path("${innovusion_pointcloud_DIR}/.." "msg" innovusion_pointcloud_MSG_INCLUDE_DIRS UNIQUE)
set(innovusion_pointcloud_MSG_DEPENDENCIES std_msgs)
