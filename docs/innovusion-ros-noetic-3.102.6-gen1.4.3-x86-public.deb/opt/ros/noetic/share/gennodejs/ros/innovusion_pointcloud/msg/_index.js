
"use strict";

let InnovusionPacket = require('./InnovusionPacket.js');
let InnovusionScan = require('./InnovusionScan.js');

module.exports = {
  InnovusionPacket: InnovusionPacket,
  InnovusionScan: InnovusionScan,
};
