// Auto-generated. Do not edit!

// (in-package innovusion_pointcloud.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class InnovusionPacket {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.has_table = null;
      this.data = null;
      this.table = null;
    }
    else {
      if (initObj.hasOwnProperty('has_table')) {
        this.has_table = initObj.has_table
      }
      else {
        this.has_table = false;
      }
      if (initObj.hasOwnProperty('data')) {
        this.data = initObj.data
      }
      else {
        this.data = [];
      }
      if (initObj.hasOwnProperty('table')) {
        this.table = initObj.table
      }
      else {
        this.table = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type InnovusionPacket
    // Serialize message field [has_table]
    bufferOffset = _serializer.bool(obj.has_table, buffer, bufferOffset);
    // Serialize message field [data]
    bufferOffset = _arraySerializer.uint8(obj.data, buffer, bufferOffset, null);
    // Serialize message field [table]
    bufferOffset = _arraySerializer.uint8(obj.table, buffer, bufferOffset, null);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type InnovusionPacket
    let len;
    let data = new InnovusionPacket(null);
    // Deserialize message field [has_table]
    data.has_table = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [data]
    data.data = _arrayDeserializer.uint8(buffer, bufferOffset, null)
    // Deserialize message field [table]
    data.table = _arrayDeserializer.uint8(buffer, bufferOffset, null)
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.data.length;
    length += object.table.length;
    return length + 9;
  }

  static datatype() {
    // Returns string type for a message object
    return 'innovusion_pointcloud/InnovusionPacket';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '7e2d146dca202c24ec9fb671e35f1cff';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool                    has_table          # table tag
    uint8[]                 data               # packet contents
    uint8[]                 table              # lidar table
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new InnovusionPacket(null);
    if (msg.has_table !== undefined) {
      resolved.has_table = msg.has_table;
    }
    else {
      resolved.has_table = false
    }

    if (msg.data !== undefined) {
      resolved.data = msg.data;
    }
    else {
      resolved.data = []
    }

    if (msg.table !== undefined) {
      resolved.table = msg.table;
    }
    else {
      resolved.table = []
    }

    return resolved;
    }
};

module.exports = InnovusionPacket;
